#Program: eHP Calculator
#Author: Seth Weaver-Rosamilia
#Last date modified 3/9/23
#Calculates effective HP for the game League of Legends

#imports tkinter, ttk, tkinter.tix, messagebox, and pillow for image handling

import tkinter as tk
from tkinter import *
from tkinter import ttk
from tkinter import messagebox
from tkinter.tix import *
from PIL import ImageTk, Image


#initializes root
root = Tk()

#assigns all images for use in program
healthIcon = ImageTk.PhotoImage(Image.open('Health_icon.png'))
armorIcon = ImageTk.PhotoImage(Image.open('Armor_icon.png'))
mrIcon = ImageTk.PhotoImage(Image.open('MR_icon.png'))
nullMM = ImageTk.PhotoImage(Image.open('NMM.png'))
clothArmor = ImageTk.PhotoImage(Image.open('Cloth Armor.png'))

#provides functionality for the "Calculate" button in the main window that opens the results window
def calculateButton():
    #runs calculateTotals and validates input
    try:
        #receives establishes eMHP, ePHP, totalHP, totalArmor, and totalMR for use in resultsWindow
        eMHP, ePHP, totalHP, totalArmor, totalMR = calculateTotals()
    #ensures HP/Armor/MR values are integers
    except ValueError:
        messagebox.showerror(title=None, message='HP/MR/Armor values must be integers')
        return

    #opens child window with results returned from calculateTotals
    resultsWindow = Toplevel(root)
    totalsFrame = ttk.Frame(resultsWindow, padding=10)
    totalsFrame.grid(column = 0, row = 0)

    totalHPLabel = ttk.Label(totalsFrame, text=f"Total HP is {totalHP}", image=healthIcon, compound='left')
    totalHPLabel.grid(column = 0, row = 0, padx = 5, pady = 5)

    totalArmorLabel = ttk.Label(totalsFrame, text=f"Total Armor is {totalArmor}", image=armorIcon, compound='left')
    totalArmorLabel.grid(column = 0, row = 1, padx = 5, pady = 5)

    totalMRLabel = ttk.Label(totalsFrame, text=f"Total MR is {totalMR}", image=mrIcon, compound='left')
    totalMRLabel.grid(column = 0, row = 2, padx = 5, pady = 5)

    resultsFrame = ttk.Frame(resultsWindow, padding=10)
    resultsFrame.grid(column = 1, row = 0)

    #allows for alt text on images
    tip=Balloon(resultsWindow)

    ePHPLabel = ttk.Label(resultsFrame, text=f"Effective HP vs. Physical Damage is {ePHP:.2f}", image=clothArmor, compound='left')
    ePHPLabel.grid(column = 1, row = 0, padx = 5, pady = 13)
    #sets alt text for ePHP image
    tip.bind_widget(ePHPLabel,balloonmsg='eHP vs. physical damage is determined by total HP and total Armor')

    eMHPLabel = ttk.Label(resultsFrame, text=f"Effective HP vs. Magic Damage is {eMHP:.2f}", image=nullMM, compound='left')
    eMHPLabel.grid(column = 1, row = 1, padx = 5, pady = 13)
    #sets alt text for eMHP image
    tip.bind_widget(eMHPLabel,balloonmsg='eHP vs. magic damage is determined by total HP and total MR')

    #closes results window
    ttk.Button(resultsFrame, text = "Close", command = resultsWindow.destroy).grid(column = 1, row = 2)

    
#calculates total HP, Armor, and MR from entry fields in main window
def calculateTotals():
    baseHP = int(baseHPInput.get())
    bonusHP = int(bonusHPInput.get())
    #total of base and bonus HP values
    totalHP = baseHP + bonusHP

    baseArmor = int(baseArmorInput.get())
    bonusArmor = int(bonusArmorInput.get())
    #total of base and bonus Armor values
    totalArmor = baseArmor + bonusArmor

    baseMR = int(baseMRInput.get())
    bonusMR = int(bonusMRInput.get())
    #total of base and bonus MR values
    totalMR = baseMR + bonusMR
        
    #effective HP vs. magic damage
    eMHP = totalHP * (1+ 0.01 * totalMR)

    #effective HP vs. physical damage
    ePHP = totalHP * (1+ 0.01 * totalArmor)

    return eMHP, ePHP, totalHP, totalArmor, totalMR

#formats main window
eHP = ttk.Frame(root, padding=10)
eHP.grid()

#HP input labels with icons and entry fields
baseHPLabel = ttk.Label(eHP, text="Enter Base HP", image=healthIcon, compound='left')
baseHPLabel.grid(column=0, row=0, padx=5, pady=5)
baseHPInput = ttk.Entry(eHP)
baseHPInput.grid(column=0, row=1, padx=5, pady=5)

bonusHPLabel = ttk.Label(eHP, text="Enter Bonus HP", image=healthIcon, compound='left')
bonusHPLabel.grid(column=0, row=2, padx=5, pady=5)
bonusHPInput = ttk.Entry(eHP)
bonusHPInput.grid(column=0, row=3, padx=5, pady=5)

#Armor input labels with icons and entry fields
baseArmorLabel = ttk.Label(eHP, text="Enter Base Armor", image=armorIcon, compound='left')
baseArmorLabel.grid(column=1, row=0, padx=5, pady=5)
baseArmorInput = ttk.Entry(eHP)
baseArmorInput.grid(column=1, row=1, padx=5, pady=5)

bonusArmorLabel = ttk.Label(eHP, text="Enter Bonus Armor", image=armorIcon, compound='left')
bonusArmorLabel.grid(column=1, row=2, padx=5, pady=5)
bonusArmorInput = ttk.Entry(eHP)
bonusArmorInput.grid(column=1, row=3, padx=5, pady=5)

#MR input labels with icons and entry fields
baseMRLabel = ttk.Label(eHP, text="Enter Base MR", image=mrIcon, compound='left')
baseMRLabel.grid(column=2, row=0, padx=5, pady=5)
baseMRInput = ttk.Entry(eHP)
baseMRInput.grid(column=2, row=1, padx=5, pady=5)

bonusMRLabel = ttk.Label(eHP, text="Enter Bonus MR", image=mrIcon, compound='left')
bonusMRLabel.grid(column=2, row=2, padx=5, pady=5)
bonusMRInput = ttk.Entry(eHP)
bonusMRInput.grid(column=2, row=3, padx=5, pady=5)

#runs calculations then opens window with results through calculateButton function
ttk.Button(eHP, text="Calculate", command = calculateButton).grid(column=0, row=5, columnspan=3, sticky=N+S+E+W, pady = 5)

#closes program
ttk.Button(eHP, text = "Exit", command = root.quit).grid(column=0, row=6, columnspan=3, sticky=N+S+E+W, pady = 5)

root.mainloop()

